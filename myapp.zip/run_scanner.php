<?php
// Verificar si el usuario está logueado (misma verificación que en dashboard.php)
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

// Función para ejecutar el script Python
function runScript() {
    // Desactivar límite de tiempo de ejecución para operaciones largas
    set_time_limit(0);
    
    // Incrementar los límites de memoria para procesar grandes cantidades de datos
    ini_set('memory_limit', '256M');
    
    // Variables para almacenar la salida
    $output = [];
    $return_code = 0;
    
    // Verificar si el script existe
    $script_path = __DIR__ . '/wifi_scanner_sqlite.py';
    if (!file_exists($script_path)) {
        error_log("ERROR: Script not found: {$script_path}");
        return [
            'success' => false,
            'output' => "Error: El archivo wifi_scanner.py no se encuentra en el servidor",
            'return_code' => -1
        ];
    }
    
    // Determinar el intérprete de Python correcto
    $python_paths = ['python', 'python3', 'py'];
    $python_path = null;
    
    foreach ($python_paths as $path) {
        $test_command = "{$path} --version 2>&1";
        exec($test_command, $version_output, $version_return_code);
        
        if ($version_return_code === 0) {
            $python_path = $path;
            error_log("Python encontrado: {$path} - Versión: {$version_output[0]}");
            break;
        }
    }
    
    if ($python_path === null) {
        error_log("ERROR: Python no encontrado en el sistema");
        return [
            'success' => false,
            'output' => "Error: Python no está instalado o no se encuentra en el PATH del sistema",
            'return_code' => -1
        ];
    }
    
    // Convertir la ruta para que funcione en PHP/Windows
    $script_path = str_replace('\\', '/', $script_path);
    
    // Registrar el comando para depuración
    $command = "{$python_path} \"{$script_path}\" 2>&1";
    error_log("Ejecutando comando: {$command}");
    
    // Ejecutar el script Python con gestión de errores completa
    try {
        // Usar proc_open para mejor manejo de la salida y errores
        $descriptorspec = [
            0 => ["pipe", "r"], // stdin
            1 => ["pipe", "w"], // stdout
            2 => ["pipe", "w"]  // stderr
        ];
        
        $process = proc_open($command, $descriptorspec, $pipes);
        
        if (is_resource($process)) {
            // Cerrar stdin ya que no lo necesitamos
            fclose($pipes[0]);
            
            // Leer stdout
            $stdout = stream_get_contents($pipes[1]);
            fclose($pipes[1]);
            
            // Leer stderr
            $stderr = stream_get_contents($pipes[2]);
            fclose($pipes[2]);
            
            // Obtener código de salida
            $return_code = proc_close($process);
            
            // Combinar stdout y stderr
            $combined_output = $stdout . $stderr;
            $output = explode("\n", $combined_output);
            
            // Registrar la salida para depuración
            error_log("Salida del comando: " . $combined_output);
            error_log("Código de retorno: {$return_code}");
            
            // Verificar si el script se ejecutó con éxito
            if ($return_code !== 0 && empty($combined_output)) {
                $output[] = "Error desconocido al ejecutar el script Python. Código de retorno: {$return_code}";
            }
        } else {
            error_log("ERROR: No se pudo iniciar el proceso");
            return [
                'success' => false,
                'output' => "Error al iniciar el proceso para ejecutar el script Python",
                'return_code' => -1
            ];
        }
        
        // Preparar la respuesta
        $response = [
            'success' => ($return_code === 0),
            'output' => implode("\n", $output),
            'return_code' => $return_code
        ];
        
        return $response;
    } catch (Exception $e) {
        error_log("Excepción al ejecutar el script: " . $e->getMessage());
        return [
            'success' => false,
            'output' => "Error: " . $e->getMessage(),
            'return_code' => -1
        ];
    }
}

// Verificar si se está enviando un parámetro de forzar redirección
$force_redirect = isset($_GET['redirect']) ? $_GET['redirect'] === '1' : false;

// Incluir configuración de base de datos SQLite
require_once 'db_config.php';

// Función para obtener el último ID de escaneo
function getLastScanId() {
    try {
        $db = getDBConnection();
        // Obtener el ID más reciente
        $stmt = $db->query("SELECT scan_id FROM scans ORDER BY scan_id DESC LIMIT 1");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result) {
            return $result['scan_id'];
        }
    } catch (PDOException $e) {
        error_log("Error al obtener el ID: " . $e->getMessage());
    }
    return null;
}

// Si se solicita solo el ID del último escaneo (para redirecciones)
if (isset($_GET['get_last_id'])) {
    $last_id = getLastScanId();
    if ($last_id) {
        echo $last_id; // Devolvemos solo el ID como texto plano
    } else {
        echo "0";
    }
    exit;
}

// Si es una petición AJAX, ejecutar el script y devolver la respuesta como JSON
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
    // Asegurarse de que no haya salida antes de los headers
    ob_clean();
    
    // Ejecutar el script y capturar el resultado
    try {
        $result = runScript();
        
        // Si el escaneo terminó, siempre devolver éxito incluso si hubo errores no fatales
        // Esto evita el error "Unexpected end of JSON input" cuando el script termina
        // pero hay errores menores
        if (!isset($result['success'])) {
            $result['success'] = true;
        }
        
        // Asegurarse de que la salida sea un JSON válido incluso si está vacía
        if (!isset($result['output']) || $result['output'] === '') {
            $result['output'] = 'El escaneo se completó pero no se generó salida.';
        }
        
        if (!isset($result['return_code'])) {
            $result['return_code'] = 0;
        }
        
        // Establecer las cabeceras adecuadas
        header('Content-Type: application/json');
        
        // Obtener el ID del último escaneo realizado
        try {
            error_log("Intentando obtener el ID del último escaneo");
            $db = getDBConnection();
            // Consultar la tabla de scans para obtener el último scan_id
            $id_query = "SELECT MAX(scan_id) as last_id FROM scans";
            error_log("Ejecutando consulta: {$id_query}");
            
            $stmt = $db->query($id_query);
            if ($stmt) {
                $id_row = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($id_row && isset($id_row['last_id'])) {
                    $last_id = $id_row['last_id'];
                    $result['last_scan_id'] = (int)$last_id;
                    error_log("ID del último escaneo: {$last_id}");
                } else {
                    error_log("No se encontraron escaneos en la BD");
                    $result['last_scan_id'] = null;
                }
                
                // Verificación adicional
                $check_query = "SELECT * FROM scans ORDER BY scan_id DESC LIMIT 1";
                $check_stmt = $db->query($check_query);
                if ($check_stmt) {
                    $check_row = $check_stmt->fetch(PDO::FETCH_ASSOC);
                    if ($check_row) {
                        error_log("Verificación: último escaneo en la BD tiene ID: {$check_row['scan_id']}");
                        // Utilizar este ID si el anterior no funcionó
                        if (empty($result['last_scan_id'])) {
                            $result['last_scan_id'] = (int)$check_row['scan_id'];
                            error_log("Usando ID alternativo: {$result['last_scan_id']}");
                        }
                    }
                }
            } else {
                error_log("Error al ejecutar la consulta");
                $result['last_scan_id'] = null;
            }
        } catch (Exception $e) {
            error_log("Error al obtener el ID del último escaneo: " . $e->getMessage());
            $result['last_scan_id'] = null;
        }
        
        // Codificar el resultado como JSON con manejo de errores
        $json_result = json_encode($result);
        
        if ($json_result === false) {
            // Si hay error en la codificación JSON, devolver un JSON válido con mensaje de error
            echo json_encode([
                'success' => true, // Indicar éxito de todas formas ya que el escaneo se completó
                'output' => 'Error al codificar la respuesta JSON: ' . json_last_error_msg(),
                'return_code' => 0
            ]);
        } else {
            echo $json_result;
        }
    } catch (Exception $e) {
        // Si hay una excepción, devolver un JSON válido con el mensaje de error
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'output' => 'Error en la ejecución del script: ' . $e->getMessage(),
            'return_code' => -1
        ]);
    }
    
    exit;
}

// Si no es AJAX, redirigir al dashboard
header('Location: dashboard.php');
?>
