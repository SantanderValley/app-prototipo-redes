<?php
// Iniciar sesión
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

// Verificar si es una petición POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

// Verificar si se proporcionó un ID
if (!isset($_POST['scan_id']) || empty($_POST['scan_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'ID de escaneo no proporcionado']);
    exit;
}

$scan_id = (int)$_POST['scan_id'];

// Conexión a la base de datos
$db_config = [
    'host' => 'localhost',
    'user' => 'root',
    'password' => '',
    'database' => 'network_security'
];

$conn = new mysqli($db_config['host'], $db_config['user'], $db_config['password'], $db_config['database']);

if ($conn->connect_error) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Error de conexión a la base de datos']);
    exit;
}

// Iniciar transacción para asegurar la integridad de los datos
$conn->begin_transaction();

try {
    // Primero eliminamos los datos relacionados en devices
    $stmt = $conn->prepare("DELETE FROM devices WHERE scan_id = ?");
    $stmt->bind_param("i", $scan_id);
    $stmt->execute();
    
    // Luego eliminamos los datos relacionados en vulnerabilities
    $stmt = $conn->prepare("DELETE FROM vulnerabilities WHERE scan_id = ?");
    $stmt->bind_param("i", $scan_id);
    $stmt->execute();
    
    // Finalmente eliminamos el registro de scans
    $stmt = $conn->prepare("DELETE FROM scans WHERE scan_id = ?");
    $stmt->bind_param("i", $scan_id);
    $stmt->execute();
    
    // Si llegamos aquí sin errores, confirmamos la transacción
    $conn->commit();
    
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'message' => 'Escaneo eliminado correctamente']);
} catch (Exception $e) {
    // Si hay un error, revertimos los cambios
    $conn->rollback();
    
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Error al eliminar el escaneo: ' . $e->getMessage()]);
}

$conn->close();
?>
